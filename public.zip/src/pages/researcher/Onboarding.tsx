import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function ResearcherOnboarding() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: "",
    specialty: "",
    researchInterests: "",
    orcid: "",
    researchgate: "",
    availableForMeetings: false,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Store data temporarily
    localStorage.setItem("researcherProfile", JSON.stringify(formData));
    navigate("/researcher/dashboard");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-indigo-50 to-white">
      <div className="bg-white p-8 rounded-2xl shadow-lg w-full max-w-md">
        <h2 className="text-2xl font-bold mb-6 text-center text-indigo-600">Researcher Onboarding</h2>
        <p className="text-gray-600 mb-6 text-center">
          Set up your researcher profile to discover collaborators and opportunities.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            name="name"
            placeholder="Full Name"
            value={formData.name}
            onChange={handleChange}
            className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-indigo-400 outline-none"
            required
          />
          <input
            type="text"
            name="specialty"
            placeholder="Specialty (e.g., Oncology, Neurology)"
            value={formData.specialty}
            onChange={handleChange}
            className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-indigo-400 outline-none"
            required
          />
          <input
            type="text"
            name="researchInterests"
            placeholder="Research Interests (e.g., Gene Therapy, Immunotherapy)"
            value={formData.researchInterests}
            onChange={handleChange}
            className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-indigo-400 outline-none"
            required
          />
          <input
            type="url"
            name="orcid"
            placeholder="ORCID Profile URL (optional)"
            value={formData.orcid}
            onChange={handleChange}
            className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-indigo-400 outline-none"
          />
          <input
            type="url"
            name="researchgate"
            placeholder="ResearchGate Profile URL (optional)"
            value={formData.researchgate}
            onChange={handleChange}
            className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-indigo-400 outline-none"
          />

          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              name="availableForMeetings"
              checked={formData.availableForMeetings}
              onChange={handleChange}
              className="h-4 w-4 text-indigo-600"
            />
            <span className="text-gray-700 text-sm">Available for meetings</span>
          </label>

          <button
            type="submit"
            className="w-full bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition font-semibold"
          >
            Continue to Dashboard →
          </button>
        </form>
      </div>
    </div>
  );
}
