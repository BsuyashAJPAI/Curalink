import { useEffect, useState } from "react";
import { fetchResearcherRecommendations } from "@/lib/api";

export default function ResearcherDashboard() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [researcher, setResearcher] = useState<any>(null);

  useEffect(() => {
    const storedResearcher = localStorage.getItem("researcherData");
    if (storedResearcher) {
      const parsed = JSON.parse(storedResearcher);
      setResearcher(parsed);
      loadRecommendations(parsed.field || "oncology");
    } else {
      setLoading(false);
    }
  }, []);

  async function loadRecommendations(field: string) {
    try {
      const result = await fetchResearcherRecommendations(field);
      setData(result);
    } catch (error) {
      console.error("Error loading researcher data:", error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return <div className="text-center mt-10 text-gray-600">Loading dashboard...</div>;
  }

  if (!researcher) {
    return (
      <div className="text-center mt-20">
        <h2 className="text-xl font-semibold mb-2">No researcher data found.</h2>
        <p className="text-gray-600">
          Please complete onboarding first at{" "}
          <a href="/researcher/onboarding" className="text-blue-600 underline">
            Researcher Onboarding
          </a>.
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-white py-10">
      <div className="container mx-auto p-6 max-w-6xl">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <h1 className="text-3xl font-bold mb-2 text-gray-800">
            Welcome, Dr. {researcher.fullName.split(" ")[0]} 👋
          </h1>
          <p className="text-gray-600">
            <span className="font-medium">Field:</span> {researcher.field} |{" "}
            <span className="font-medium">Specialty:</span> {researcher.specialty} |{" "}
            <span className="font-medium">Location:</span> {researcher.location}
          </p>
        </div>

        {/* Section 1: Recommended Collaborators */}
        <h2 className="text-2xl font-bold mb-4 text-gray-800">Recommended Collaborators</h2>
        <div className="grid md:grid-cols-3 gap-6 mb-10">
          {data?.collaborators?.length ? (
            data.collaborators.map((col: any, index: number) => (
              <div
                key={index}
                className="p-5 bg-white border rounded-xl shadow-sm hover:shadow-lg transition"
              >
                <h3 className="text-lg font-semibold mb-1">{col.name}</h3>
                <p className="text-sm text-gray-600 mb-1">{col.specialty}</p>
                <p className="text-sm text-gray-500 mb-2">{col.institution}</p>
                <button className="text-sm bg-blue-600 text-white px-3 py-1 rounded-md hover:bg-blue-700 transition">
                  Connect
                </button>
              </div>
            ))
          ) : (
            <p className="text-gray-500 col-span-3">No collaborator suggestions available.</p>
          )}
        </div>

        {/* Section 2: Relevant Clinical Trials */}
        <h2 className="text-2xl font-bold mb-4 text-gray-800">Relevant Clinical Trials</h2>
        <div className="grid md:grid-cols-3 gap-6 mb-10">
          {data?.trials?.length ? (
            data.trials.map((trial: any, index: number) => (
              <div
                key={index}
                className="p-5 bg-white border rounded-xl shadow-sm hover:shadow-lg transition"
              >
                <h3 className="text-lg font-semibold mb-1">{trial.title}</h3>
                <p className="text-sm text-gray-600 mb-1">Phase: {trial.phase}</p>
                <p className="text-sm text-gray-500">Status: {trial.status}</p>
              </div>
            ))
          ) : (
            <p className="text-gray-500 col-span-3">No related trials found.</p>
          )}
        </div>

        {/* Section 3: Publications */}
        <h2 className="text-2xl font-bold mb-4 text-gray-800">Latest Publications</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {data?.publications?.length ? (
            data.publications.map((pub: any, index: number) => (
              <div
                key={index}
                className="p-5 bg-white border rounded-xl shadow-sm hover:shadow-lg transition"
              >
                <h3 className="text-lg font-semibold mb-2">{pub.title}</h3>
                <p className="text-sm text-gray-600 mb-1">Authors: {pub.authors}</p>
                <a
                  href={pub.url}
                  target="_blank"
                  className="text-blue-600 text-sm font-medium hover:underline"
                >
                  View Publication
                </a>
              </div>
            ))
          ) : (
            <p className="text-gray-500 col-span-2">No publications found.</p>
          )}
        </div>
      </div>
    </div>
  );
}
