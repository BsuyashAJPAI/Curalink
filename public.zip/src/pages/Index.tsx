import { Hero } from "@/components/Hero";
import { HangingCard } from "@/components/HangingCard";
import { Users, Stethoscope } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";

const Index = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
const handlePatientStart = () => {
  toast({
    title: "Welcome, Patient!",
    description: "Redirecting you to patient onboarding...",
  });
  setTimeout(() => navigate("/patient/onboarding"), 800);
};

const handleDoctorStart = () => {
  toast({
    title: "Welcome, Researcher!",
    description: "Redirecting you to researcher onboarding...",
  });
  setTimeout(() => navigate("/researcher/onboarding"), 800);
};



  return (
    <div className="min-h-screen bg-gradient-hero">
      <div className="container mx-auto px-4 py-16">
        <Hero />

        <div className="mt-24 mb-16">
          <h2 className="text-3xl font-bold text-center mb-4">
            How would you like to get started?
          </h2>
        </div>

        <div className="flex flex-wrap justify-center gap-16 pt-16 pb-8">
          <HangingCard
            icon={Users}
            title="I am a Patient or Caregiver"
            description="Find trusted doctors, manage appointments, and access healthcare services easily."
            onClick={handlePatientStart}
          />
          <HangingCard
            icon={Stethoscope}
            title="I am a Researcher"
            description="Connect with patients, manage consultations, and grow your professional network."
            onClick={handleDoctorStart}
          />
        </div>

        <footer className="mt-16 text-center text-sm text-muted-foreground">
          © 2025 <span className="font-semibold text-primary">CuraLink</span>. All rights reserved.
        </footer>
      </div>
    </div>
  );
};

export default Index;
