import { useEffect, useState } from "react";
import { fetchPatientRecommendations } from "@/lib/api";

export default function PatientDashboard() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [patient, setPatient] = useState<any>(null);

  useEffect(() => {
    // ✅ Load patient details from localStorage
    const storedPatient = localStorage.getItem("patientData");
    if (storedPatient) {
      const parsed = JSON.parse(storedPatient);
      setPatient(parsed);

      // Fetch recommendations based on patient condition
      loadRecommendations(parsed.condition);
    } else {
      setLoading(false);
    }
  }, []);

  async function loadRecommendations(condition: string) {
    try {
      const result = await fetchPatientRecommendations(condition);
      setData(result);
    } catch (error) {
      console.error("Error loading recommendations:", error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return <div className="text-center mt-10 text-gray-600">Loading recommendations...</div>;
  }

  if (!patient) {
    return (
      <div className="text-center mt-20">
        <h2 className="text-xl font-semibold mb-2">No patient data found.</h2>
        <p className="text-gray-600">
          Please complete onboarding first at{" "}
          <a href="/patient/onboarding" className="text-blue-600 underline">
            Patient Onboarding
          </a>.
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white py-10">
      <div className="container mx-auto p-6 max-w-5xl">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <h1 className="text-3xl font-bold mb-2 text-gray-800">
            Welcome, {patient.fullName.split(" ")[0]} 👋
          </h1>
          <p className="text-gray-600">
            <span className="font-medium">Age:</span> {patient.age} |{" "}
            <span className="font-medium">Gender:</span> {patient.gender} |{" "}
            <span className="font-medium">Condition:</span> {patient.condition} |{" "}
            <span className="font-medium">Location:</span> {patient.location}
          </p>
        </div>

        {/* Recommendations */}
        <h2 className="text-2xl font-bold mb-4 text-gray-800">Recommended Clinical Trials</h2>
        <div className="grid md:grid-cols-3 gap-6 mb-10">
          {data?.recommended_trials?.length ? (
            data.recommended_trials.map((trial: any, index: number) => (
              <div
                key={index}
                className="p-5 bg-white border rounded-xl shadow-sm hover:shadow-lg transition"
              >
                <h3 className="text-lg font-semibold mb-1">{trial.title}</h3>
                <p className="text-sm text-gray-600 mb-1">Phase: {trial.phase}</p>
                <p className="text-sm text-gray-500">Status: {trial.status}</p>
              </div>
            ))
          ) : (
            <p className="text-gray-500 col-span-3">No trials found for this condition.</p>
          )}
        </div>

        <h2 className="text-2xl font-bold mb-4 text-gray-800">Related Publications</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {data?.publications?.length ? (
            data.publications.map((pub: any, index: number) => (
              <div
                key={index}
                className="p-5 bg-white border rounded-xl shadow-sm hover:shadow-lg transition"
              >
                <h3 className="text-lg font-semibold mb-2">{pub.title}</h3>
                <p className="text-sm text-gray-600 mb-1">Authors: {pub.authors}</p>
                <a
                  href={pub.url}
                  target="_blank"
                  className="text-blue-600 text-sm font-medium hover:underline"
                >
                  View Publication
                </a>
              </div>
            ))
          ) : (
            <p className="text-gray-500 col-span-2">No related publications found.</p>
          )}
        </div>
      </div>
    </div>
  );
}
