const API_BASE = "http://127.0.0.1:8000/api";



export async function fetchPatientRecommendations(condition: string) {
    const res = await fetch(`${API_BASE}/patient/recommendations?condition=${condition}`);
    return res.json();
}

export async function fetchResearcherRecommendations(field: string) {
    const res = await fetch(`${API_BASE}/researcher/recommendations?field=${field}`);
    return res.json();
}

export async function fetchClinicalTrials(condition: string) {
    const res = await fetch(`${API_BASE}/trials/search?condition=${condition}`);
    return res.json();
}
