import { Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import ResearcherOnboarding from "./pages/researcher/Onboarding";
import PatientDashboard from "./pages/patient/Dashboard";
import ResearcherDashboard from "./pages/researcher/Dashboard";
import NotFound from "./pages/NotFound";
import PatientOnboarding from "./pages/patient/Onboarding";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Index />} />
      <Route path="/patient/onboarding" element={<PatientOnboarding />} />
      <Route path="/patient/dashboard" element={<PatientDashboard />} />
      <Route path="/researcher/onboarding" element={<ResearcherOnboarding />} />
      <Route path="/researcher/dashboard" element={<ResearcherDashboard />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default App;
