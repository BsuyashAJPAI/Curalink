import { Heart } from "lucide-react";

export const Hero = () => {
  return (
    <div className="text-center space-y-6 animate-fade-in">
      <div className="flex items-center justify-center gap-3 mb-4">
        <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center">
          <Heart className="w-6 h-6 text-white fill-white" />
        </div>
        <h1 className="text-5xl md:text-6xl font-bold bg-gradient-primary bg-clip-text text-transparent">
          CuraLink
        </h1>
      </div>
      <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
        Connecting patients and doctors to provide seamless healthcare access and smart digital experiences.
      </p>
    </div>
  );
};
