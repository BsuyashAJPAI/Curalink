import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LucideIcon } from "lucide-react";

interface RoleCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  onGetStarted: () => void;
}

export const RoleCard = ({ icon: Icon, title, description, onGetStarted }: RoleCardProps) => {
  return (
    <Card className="group relative overflow-hidden border-2 hover:border-primary transition-all duration-300 hover:shadow-card-hover animate-scale-in">
      <div className="absolute inset-0 bg-gradient-primary opacity-0 group-hover:opacity-5 transition-opacity duration-300" />
      <CardContent className="p-8 space-y-6">
        <div className="w-16 h-16 rounded-2xl bg-gradient-primary flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
          <Icon className="w-8 h-8 text-white" />
        </div>
        <div className="space-y-3">
          <h3 className="text-2xl font-bold text-card-foreground">{title}</h3>
          <p className="text-muted-foreground leading-relaxed">{description}</p>
        </div>
        <Button 
          onClick={onGetStarted}
          className="w-full bg-gradient-primary hover:opacity-90 transition-opacity text-white font-semibold py-6"
          size="lg"
        >
          Get Started
        </Button>
      </CardContent>
    </Card>
  );
};
