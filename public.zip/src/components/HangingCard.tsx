import { motion } from "framer-motion";
import { LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface HangingCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  onClick: () => void;
}

export const HangingCard = ({ icon: Icon, title, description, onClick }: HangingCardProps) => {
  return (
    <motion.div
      initial={{ y: -100, opacity: 0, rotate: -3 }}
      animate={{
        y: 0,
        opacity: 1,
        rotate: [0, 1.5, -1.5, 1, -1, 0],
      }}
      transition={{
        y: { type: "spring", stiffness: 80, damping: 10 },
        rotate: {
          repeat: Infinity,
          duration: 6,
          ease: "easeInOut",
        },
      }}
      whileHover={{
        rotate: [0, 3, -3, 2, -2, 0],
        transition: { duration: 0.8, ease: "easeInOut" },
      }}
      className="relative"
    >
      {/* Dotted hanging wire */}
      <div className="absolute top-[-60px] left-1/2 -translate-x-1/2 w-[2px] h-[60px] border-l-2 border-dotted border-muted-foreground/40"></div>

      <Card className="relative border-2 shadow-card hover:shadow-card-hover transition-shadow duration-300 w-80">
        <CardContent className="p-8 flex flex-col items-center space-y-4">
          {/* Icon */}
          <div className="w-16 h-16 rounded-2xl bg-gradient-primary flex items-center justify-center">
            <Icon className="w-8 h-8 text-white" />
          </div>

          {/* Title */}
          <h3 className="text-xl font-bold text-card-foreground text-center">
            {title}
          </h3>

          {/* Description */}
          <p className="text-muted-foreground text-center leading-relaxed">
            {description}
          </p>

          {/* Button */}
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="w-full pt-2"
          >
            <Button
              onClick={onClick}
              className="w-full bg-gradient-primary hover:opacity-90 transition-opacity text-white font-semibold py-6"
              size="lg"
            >
              Get Started
            </Button>
          </motion.div>
        </CardContent>
      </Card>
    </motion.div>
  );
};
