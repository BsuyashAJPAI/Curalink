import aiohttp

BASE_URL = "https://clinicaltrials.gov/api/v2/studies"

async def get_trials(condition: str):
    # Build request to new v2 endpoint
    url = f"{BASE_URL}?filter.overallStatus=RECRUITING&query.term={condition}&pageSize=5"
    
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            if resp.status != 200:
                # In case of bad response, show text for debugging
                text = await resp.text()
                raise Exception(f"ClinicalTrials.gov API error ({resp.status}): {text}")
            
            data = await resp.json()

            # Parse results properly according to new structure
            studies = data.get("studies", [])
            results = []

            for s in studies:
                protocol = s.get("protocolSection", {})
                identification = protocol.get("identificationModule", {})
                status = protocol.get("statusModule", {})
                description = protocol.get("descriptionModule", {})

                results.append({
                    "title": identification.get("briefTitle", "N/A"),
                    "status": status.get("overallStatus", "N/A"),
                    "phase": status.get("phase", "N/A"),
                    "country": protocol.get("contactsLocationsModule", {}).get("locations", [{}])[0].get("country", "N/A"),
                    "summary": description.get("briefSummary", "N/A"),
                })

            return results
