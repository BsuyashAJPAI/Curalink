import aiohttp

async def get_publications(condition: str):
    url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term={condition}&retmax=5&retmode=json"
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            data = await resp.json()
            ids = data["esearchresult"].get("idlist", [])
    results = []
    for pid in ids:
        results.append({
            "title": f"Publication related to {condition} (ID: {pid})",
            "pubmed_id": pid,
        })
    return results
