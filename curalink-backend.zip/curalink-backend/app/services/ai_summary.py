async def summarize_trial(trial_title: str, phase: str, status: str):
    """Stub for future AI-based summarization."""
    return f"{trial_title} is currently in {phase} phase and has {status} status."
