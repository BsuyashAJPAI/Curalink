from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import patient, researcher

app = FastAPI()

# ✅ Allow frontend (port 8080) to call backend (port 8000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:8080",  # your frontend
        "http://127.0.0.1:8080",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ✅ Include routes under /api
app.include_router(patient.router, prefix="/api/patient")
app.include_router(researcher.router, prefix="/api/researcher")

@app.get("/")
def read_root():
    return {"message": "CuraLink API is running!"}
