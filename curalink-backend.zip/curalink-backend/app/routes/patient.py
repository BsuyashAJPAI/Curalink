from fastapi import APIRouter
from app.services.clinical_trials import get_trials
from app.services.publications import get_publications

router = APIRouter()

@router.get("/recommendations")
async def patient_recommendations(condition: str = "glioma"):
    """Return recommended trials and publications for a patient"""
    trials = await get_trials(condition)
    pubs = await get_publications(condition)
    return {
        "condition": condition,
        "recommended_trials": trials,
        "publications": pubs,
    }
