from fastapi import APIRouter
from app.services.clinical_trials import get_trials
from app.services.publications import get_publications

router = APIRouter()

@router.get("/recommendations")
async def researcher_recommendations(field: str = "oncology"):
    """Return research recommendations"""
    trials = await get_trials(field)
    pubs = await get_publications(field)
    collaborators = [
        {"name": "Dr. Sarah Chen", "specialty": "Neuro-Oncology", "institution": "Stanford University"},
        {"name": "Dr. David Kumar", "specialty": "Immunotherapy", "institution": "AIIMS New Delhi"},
        {"name": "Dr. Elena Garcia", "specialty": "Clinical AI", "institution": "University of Barcelona"},
    ]
    return {
        "field": field,
        "collaborators": collaborators,
        "trials": trials,
        "publications": pubs,
    }
