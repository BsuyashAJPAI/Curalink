from fastapi import APIRouter, Query
from app.services.clinical_trials import get_trials

router = APIRouter()

@router.get("/search")
async def search_trials(query: str = Query(..., description="Disease or condition name")):
    trials = await get_trials(query)
    return {"query": query, "results": trials}
